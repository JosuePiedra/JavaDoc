package ec.edu.utpl.poo.semana13.pruebaparcial;

public enum TITULOS {
    LICENCIADO,
    INGENIERO,
    MAGISTER,
    PHD
}
