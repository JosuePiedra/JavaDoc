package ec.edu.utpl.poo.semana13.pruebaparcial.sueldos;

import ec.edu.utpl.poo.semana13.pruebaparcial.Curso;
import ec.edu.utpl.poo.semana13.pruebaparcial.Fisico;
import ec.edu.utpl.poo.semana13.pruebaparcial.Presencial;

public class CalculoTotalForma2 implements ICalculaTotalMatricula{

    @Override
    public double calcularTotalMatricula(Curso curso) {
        double costoDocente = curso.getDocente().getSueldo();
        double costoRecursos = 0;

        for (var i: curso.getRecursos()){
            if (i instanceof Fisico){
                costoRecursos += i.getCosto() + i.getCosto() * 10/100;
            }else{
                costoRecursos += i.getCosto() - i.getCosto() * 3/100;
            }
        }

        double costoTipoCurso = (costoDocente + costoRecursos + curso.getCostoBase()) * 5/100;

        if (curso.getTipo() == 0){
            return costoDocente + costoRecursos + curso.getCostoBase() + costoTipoCurso;
        }else{
            return costoDocente + costoRecursos + curso.getCostoBase() - costoTipoCurso;
        }
    }
}
