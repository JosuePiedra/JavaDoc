package ec.edu.utpl.poo.semana13.pruebaparcial;

public class Online extends Curso {
    String salaID;

    public Online(int tipoCurso, double nombre, int numHoras, double costoBase, String horario,
                      Docente docente) {
        this.setTipo(tipoCurso);
        this.setNombre(nombre);
        this.setNumHoras(numHoras);
        this.setCostoBase(costoBase);
        this.setHorario(horario);
        this.setDocente(docente);
    }

}
