package ec.edu.utpl.poo.semana13.pruebaparcial.sueldos;

import ec.edu.utpl.poo.semana13.pruebaparcial.Curso;

public class CalculoTotalForma4 implements ICalculaTotalMatricula{

    @Override
    public double calcularTotalMatricula(Curso curso) {
        double costoTotal, costoRecursos = 0;

        for (var i: curso.getRecursos()){
            costoRecursos += i.getCosto();
        }

        return costoTotal = curso.getCostoBase() + costoRecursos + curso.getDocente().getSueldo();

    }
}
