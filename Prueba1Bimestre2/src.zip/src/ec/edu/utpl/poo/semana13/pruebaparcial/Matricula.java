package ec.edu.utpl.poo.semana13.pruebaparcial;

import ec.edu.utpl.poo.semana13.pruebaparcial.sueldos.ICalculaTotalMatricula;

public class Matricula {
    private int numero;
    private double descuento;
    private Curso curso;
    private int tipoCurso;
    private ICalculaTotalMatricula algoritmo;

    public Matricula(int tipoCurso, int numero, double nombre, int numHoras,
                     double costoBase, String horario, Docente docente) {
        this.setNumero(numero);
        this.setDescuento(getDescuento());
        if (tipoCurso == 0){
            curso = new Presencial(0,nombre, numHoras,costoBase,horario,docente);
        }else{
            curso = new Online(1, nombre, numHoras,costoBase,horario,docente);
        }

    }

    public Matricula(int tipoCurso,int numero, Curso curso, double nombre, int numHoras,
                     double costoBase, String horario, Docente docente, double descuento) {
        this.setNumero(numero);
        this.setDescuento(descuento);
        if (tipoCurso == 0){
            curso = new Presencial(0,nombre, numHoras,costoBase,horario,docente);
        }else{
            curso = new Online(1,nombre, numHoras,costoBase,horario,docente);
        }
    }

    public double calcularCosto(ICalculaTotalMatricula algoritmo){
        double costoTotal = algoritmo.calcularTotalMatricula(this.curso);
        if(getDescuento() == 0){
            return costoTotal;
        }else{
            return costoTotal - (costoTotal * getDescuento() /100);
        }

    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public int getTipoCurso() {
        return tipoCurso;
    }

    public void setTipoCurso(int tipoCurso) {
        this.tipoCurso = tipoCurso;
    }

    public ICalculaTotalMatricula getAlgoritmo() {
        return algoritmo;
    }

    public void setAlgoritmo(ICalculaTotalMatricula algoritmo) {
        this.algoritmo = algoritmo;
    }
}
