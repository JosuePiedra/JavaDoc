package ec.edu.utpl.poo.semana13.pruebaparcial.sueldos;

import ec.edu.utpl.poo.semana13.pruebaparcial.Curso;
import ec.edu.utpl.poo.semana13.pruebaparcial.Matricula;

public interface ICalculaTotalMatricula {
    double calcularTotalMatricula(Curso curso);
}
