package ec.edu.utpl.poo.semana13.pruebaparcial;

public abstract class Recurso {
    private double costo;

    public Recurso(double costo) {
        this.setCosto(costo);
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }
}
