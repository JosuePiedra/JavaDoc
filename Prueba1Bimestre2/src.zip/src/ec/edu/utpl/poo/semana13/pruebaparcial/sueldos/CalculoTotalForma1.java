package ec.edu.utpl.poo.semana13.pruebaparcial.sueldos;

import ec.edu.utpl.poo.semana13.pruebaparcial.Curso;
import ec.edu.utpl.poo.semana13.pruebaparcial.TITULOS;

public class CalculoTotalForma1 implements ICalculaTotalMatricula{
    @Override
    public double calcularTotalMatricula(Curso curso) {
        double costoRecursos = 0;
        for (var i: curso.getRecursos()){
            costoRecursos += i.getCosto();
        }
        double salarioDocente = curso.getDocente().getSueldo();
        double costoTotal = curso.getCostoBase() + salarioDocente + costoRecursos;
        if (curso.getDocente().getTitulo() == TITULOS.LICENCIADO){
            return costoTotal + (costoTotal * 10/100) ;
        }else if(curso.getDocente().getTitulo() == TITULOS.INGENIERO){
            return costoTotal + (costoTotal * 12.5/100) ;
        }else if(curso.getDocente().getTitulo() == TITULOS.MAGISTER){
            return costoTotal + (costoTotal * 15/100) ;
        }else{
            return costoTotal + (costoTotal * 17.5/100) ;
        }
    }

}
