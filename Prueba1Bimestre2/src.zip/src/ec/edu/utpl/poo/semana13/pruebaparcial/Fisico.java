package ec.edu.utpl.poo.semana13.pruebaparcial;

public class Fisico extends Recurso{
    private String isbn;

    public Fisico(double costo, String isbn) {
        super(costo);
        this.isbn = isbn;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}


