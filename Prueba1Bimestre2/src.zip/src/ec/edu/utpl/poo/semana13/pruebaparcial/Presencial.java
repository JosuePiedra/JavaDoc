package ec.edu.utpl.poo.semana13.pruebaparcial;

public class Presencial extends Curso{
    String aula;

    public Presencial(int tipoCurso, double nombre, int numHoras, double costoBase, String horario,
                      Docente docente) {
        this.setTipo(tipoCurso);
        this.setNombre(nombre);
        this.setNumHoras(numHoras);
        this.setCostoBase(costoBase);
        this.setHorario(horario);
        this.setDocente(docente);
    }

    public void setAula(String aula) {
        this.aula = aula;
    }
}
