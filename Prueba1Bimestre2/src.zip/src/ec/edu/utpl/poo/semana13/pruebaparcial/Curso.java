package ec.edu.utpl.poo.semana13.pruebaparcial;

import java.util.ArrayList;
import java.util.List;

public abstract class Curso {
    private double nombre;
    private int numHoras;
    private double costoBase;
    private String horario;
    private List<Recurso> recursos = new ArrayList<>();
    private Docente docente;
    private int tipo;

    public void addRecursos(Recurso recurso){
        getRecursos().add(recurso);
    }

    public double getNombre() {
        return nombre;
    }

    public void setNombre(double nombre) {
        this.nombre = nombre;
    }

    public int getNumHoras() {
        return numHoras;
    }

    public void setNumHoras(int numHoras) {
        this.numHoras = numHoras;
    }

    public double getCostoBase() {
        return costoBase;
    }

    public void setCostoBase(double costoBase) {
        this.costoBase = costoBase;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public List<Recurso> getRecursos() {
        return recursos;
    }

    public void setRecursos(List<Recurso> recursos) {
        this.recursos = recursos;
    }

    public Docente getDocente() {
        return docente;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public void setDocente(Docente docente) {
        this.docente = docente;
    }
}
