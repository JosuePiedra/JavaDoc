package ec.edu.utpl.poo.semana13.pruebaparcial;

public class Virtual extends Recurso {
    private String url;
    public Virtual(double costo, String url) {
        super(costo);
        this.setUrl(url);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}

