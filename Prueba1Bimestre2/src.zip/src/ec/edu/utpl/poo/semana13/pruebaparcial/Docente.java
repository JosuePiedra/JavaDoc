package ec.edu.utpl.poo.semana13.pruebaparcial;

public class Docente {
    private TITULOS titulo;
    private double sueldo;


    public Docente(TITULOS titulo, double sueldo) {
        this.titulo = titulo;
        this.sueldo = sueldo;
    }

    public TITULOS getTitulo() {
        return titulo;
    }

    public void setTitulo(TITULOS titulo) {
        this.titulo = titulo;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }
}
